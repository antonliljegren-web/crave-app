# 🍽️ Crave — Tinder for Food

Swipe restaurants solo or with friends. Real Google Places data, real photos, group matching.

---

## Deploy to Vercel (10 minutes)

### 1. Upload to GitHub
Drag all files from this folder into your `crave-app` GitHub repo.

### 2. Connect to Vercel
1. Go to [vercel.com](https://vercel.com) → sign in with GitHub
2. **Add New Project** → import your `crave-app` repo
3. Click **Deploy** (it will fail first time — that's fine, next step fixes it)

### 3. Add environment variable
In Vercel dashboard → your project → **Settings → Environment Variables**:
- `GOOGLE_API_KEY` = your Google Places API key

**Required Google APIs** (enable at [console.cloud.google.com](https://console.cloud.google.com)):
- ✅ Places API
- ✅ Maps JavaScript API

### 4. Add Vercel KV (for group sessions — free)
Group mode requires a Redis store to share session state between users.

1. In Vercel dashboard → your project → **Storage** tab
2. Click **Create Database** → choose **KV (Redis)**
3. Name it `crave-kv` → Create
4. Click **Connect to Project** → select your project
5. Vercel auto-adds the KV environment variables — done ✅

Then **redeploy** (Vercel dashboard → Deployments → Redeploy).

---

## How group mode works

1. Creator picks Group mode, enters name, clicks Find Food
2. App fetches restaurants and creates a session in KV store
3. Creator gets a shareable link: `yourcrave.vercel.app/?join=AB3XY`
4. Friends open the link, enter their name, start swiping the same restaurants
5. When 2+ people swipe right on the same place → it's a group match 🎉
6. Live toast: "🎉 Anton & Vilma matched: Burger & Lobster!"
7. Group panel shows all shared matches + who's swiped how many

---

## File structure
```
crave-app/
├── api/
│   ├── nearby.js    ← Google Places search proxy
│   ├── photo.js     ← Restaurant photo proxy  
│   └── group.js     ← Group session API (uses Vercel KV)
├── public/
│   └── index.html   ← Entire frontend
├── vercel.json      ← Routing config
└── README.md
```

---

## Features

| Feature | Solo | Group |
|---|---|---|
| Swipe restaurants with real photos | ✅ | ✅ |
| Personal library (save matches) | ✅ | ✅ |
| Undo last swipe | ✅ | ✅ |
| Keyboard shortcuts (← → I Z) | ✅ | ✅ |
| 🎲 Random pick from library | ✅ | ✅ |
| 📊 Stats (cuisines, streaks, rate) | ✅ (with account) | ✅ |
| Shareable join link | — | ✅ |
| See who else liked a card | — | ✅ |
| Live group match toasts | — | ✅ |
| Group progress panel | — | ✅ |

---

## Customise

- **Default fallback city**: edit `doFetch` fallback coords in `public/index.html`
- **Match threshold**: in `api/group.js`, change `names.length >= 2` to require more people
- **Session expiry**: in `api/group.js`, change `TTL = 60 * 60 * 6` (currently 6 hours)
- **Real auth**: replace `localStorage` user store with Supabase or Auth0
